<?php

/////////////////////////////////////////
//  LICENSE GAMES BY     : INDOAPIVOXS //
//  SOURCE CODE BUILD BY : ZULHAYKER   //
//  COPYRIGHT @2024------ALL RESERVED  //   
/////////////////////////////////////////

class zulhayker
{
    private $agent_code = ""; 
    private $agent_token = "";  
    private $url_request = "https://myserverku.eu.org/api/connect";

    public function Create($username)
    {
        $action = $this->url_request . "?cmd=createuser&agent_code=" . $this->agent_code . "&agent_token=" . $this->agent_token . "&username=" . $username;
        return $this->connect($action);
    }

    public function GameList($provider)
    {
        $action = $this->url_request . "?cmd=gamelist&agent_code=" . $this->agent_code . "&agent_token=" . $this->agent_token . "&provider=" . $provider;
        return $this->connect($action);
    }

    public function ProviderList()
    {
        $action = $this->url_request . "?cmd=providerlist&agent_code=" . $this->agent_code . "&agent_token=" . $this->agent_token;
        return $this->connect($action);
    }

    public function OpenGame($username, $provider, $game_code)
    {
        $action = $this->url_request . "?cmd=opengame&agent_code=" . $this->agent_code . "&agent_token=" . $this->agent_token . "&username=" . $username . "&provider=" . $provider . "&gamecode=" . $game_code;
        return $this->connect($action);
    }

    public function Transaksi($username, $amount, $type)
    {
        $action = $this->url_request . "?cmd=transaksi&agent_code=" . $this->agent_code . "&agent_token=" . $this->agent_token . "&username=" . $username . "&type=" . $type . "&amount=" . $amount;
        return $this->connect($action);
    }

    public function GetBalance($username)
    {
        $action = $this->url_request . "?cmd=getbalance&agent_code=" . $this->agent_code . "&agent_token=" . $this->agent_token . "&username=" . $username;
        return $this->connect($action);
    }

    public function InfoAgent()
    {
        $action = $this->url_request . "?cmd=getbalanceagent&agent_code=" . $this->agent_code . "&agent_token=" . $this->agent_token;
        return $this->connect($action);
    }

    public function Turnover($username)
    {
        $action = $this->url_request . "?cmd=turnover&agent_code=" . $this->agent_code . "&agent_token=" . $this->agent_token. "&username=" . $username;
        return $this->connect($action);
    }

    private function connect($url)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        curl_setopt($ch, CURLOPT_AUTOREFERER, TRUE);
        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/51.0.2704.47 Safari/537.36');
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, TRUE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TCP_KEEPALIVE, 1);
        curl_setopt($ch, CURLOPT_TCP_KEEPIDLE, 2);
        curl_setopt($ch, CURLOPT_TCP_KEEPINTVL, 3);
        $output = curl_exec($ch);
        curl_close($ch);

        return $output;
    }
}

$ZH = new zulhayker();
?>
