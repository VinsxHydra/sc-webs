<!-- Account Balance -->
<?php
// Mendapatkan status maintenance per game
$result = mysqli_query($koneksi, "SELECT * FROM game_maintenance");
$game_maintenance_status = [];
while ($row = mysqli_fetch_assoc($result)) {
    $game_maintenance_status[$row['game_code']] = $row['is_maintenance'];
}
?>
<main id="main-route">
    <div class="main-content game">
        <div class="container">
            <div class="game__list">
                <div class="page-header">Slot</div>
                <div class="game-list-container">
                <?php 
                if (empty($id_login)) { 
                    ?>
                            <div class="game-holder">
                            <div class="game-img">
                                <img title="PRAGMATIC PLAY" alt="PRAGMATIC PLAY"
                                src="https://images.linkcdn.cloud/global/banner/paramatic_20play.jpg">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">PRAGMATIC PLAY</div>
                                <div class="game-links main-sekarang-alert">
                                    <a class="btn-custom" href="?page=slot_pragmatic">
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <div class="game-holder">
                            <div class="game-img">
                                <img title="PG SOFT" alt="PG SOFT" 
                                src="https://images.linkcdn.cloud/global/banner/pgsoftegame.jpg">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">PGSOFT</div>
                                <div class="game-links main-sekarang-alert">
                                    <a class="btn-custom" href="?page=slot_pgsoft">
                                        Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <div class="game-holder">
                            <div class="game-img">
                                <img title="HABANERO" alt="HABANERO" 
                                src="https://images.linkcdn.cloud/global/banner/habanero.jpg">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">HABANERO</div>
                                <div class="game-links main-sekarang-alert">
                                    <a class="btn-custom" href="?page=slot_habanero">
                                        Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <div class="game-holder">
                            <div class="game-img">
                                <img title="CQ9" alt="CQ9"
                                src="https://images.linkcdn.cloud/global/banner/cq9.jpg">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">CQ9</div>
                                <div class="game-links main-sekarang-alert">
                                    <a class="btn-custom" href="?page=slot_cq9">
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <div class="game-holder">
                            <div class="game-img">
                                <img title="TOPTREND" alt="TOPTREND"
                                src="https://images.linkcdn.cloud/global/banner/top_trend_gaming.jpg" style="height: 50px">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">TOPTREND</div>
                                <div class="game-links main-sekarang-alert">
                                    <a class="btn-custom" href="?page=slot_toptrend" >
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <div class="game-holder">
                            <div class="game-img">
                                <img title="DREAMTECH" alt="DREAMTECH"
                                src="<?php echo $urlweb?>/uploads/provider/dreamtech.png" style="height: 50px">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">DREAMTECH</div>
                                <div class="game-links main-sekarang-alert">
                                    <a class="btn-custom" href="?page=slot_dreamtech" >
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <div class="game-holder">
                            <div class="game-img">
                                <img title="BOOONGO" alt="BOOONGO"
                                src="<?php echo $urlweb?>/uploads/provider/booongo.png">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">BOOONGO</div>
                                <div class="game-links main-sekarang-alert">
                                    <a class="btn-custom" href="?page=slot_booongo">
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <div class="game-holder">
                            <div class="game-img">
                                <img title="PLAYSON" alt="PLAYSON"
                                src="<?php echo $urlweb?>/uploads/provider/playson.png">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">PLAYSON</div>
                                <div class="game-links main-sekarang-alert">
                                    <a class="btn-custom" href="?page=slot_playson">
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <div class="game-holder">
                            <div class="game-img">
                                <img title="EVOPLAY" alt="EVOPLAY"
                                src="<?php echo $urlweb?>/uploads/provider/evoplay.png">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">EVOPLAY</div>
                                <div class="game-links main-sekarang-alert">
                                    <a class="btn-custom" href="?page=slot_evoplay">
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                         <div class="game-holder">
                            <div class="game-img">
                                <img title="REELKINGDOM" alt="REELKINGDOM"
                                src="<?php echo $urlweb?>/uploads/provider/reelkingdom.png" style="height: 50px">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">REELKINGDOM</div>
                                <div class="game-links main-sekarang-alert">
                                    <a class="btn-custom" href="?page=slot_reelkingdom" >
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <?php
                    }else{
                        ?>
                        <script>
                        var gameMaintenanceStatus = <?php echo json_encode($game_maintenance_status); ?>;
                        </script>
                            <div class="game-holder">
                            <div class="game-img">
                                <img title="PRAGMATIC PLAY" alt="PRAGMATIC PLAY"
                                src="https://images.linkcdn.cloud/global/banner/paramatic_20play.jpg">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">PRAGMATIC PLAY</div>
                                <div class="game-links main-sekarang-alert">
                                <a class="btn-custom" href="javascript:;" onclick="gameMaintenance('slot_pragmatic', '?page=slot_pragmatic')">
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <div class="game-holder">
                            <div class="game-img">
                                <img title="PG SOFT" alt="PG SOFT" src="https://images.linkcdn.cloud/global/banner/pgsoftegame.jpg">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">PGSOFT</div>
                                <div class="game-links main-sekarang-alert">
                                <a class="btn-custom" href="javascript:;" onclick="gameMaintenance('slot_pgsoft', '?page=slot_pgsoft')">
                                        Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <div class="game-holder">
                            <div class="game-img">
                                <img title="HABANERO" alt="HABANERO"
                                src="https://images.linkcdn.cloud/global/banner/habanero.jpg">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">HABANERO</div>
                                <div class="game-links main-sekarang-alert">
                                <a class="btn-custom" href="javascript:;" onclick="gameMaintenance('slot_habanero', '?page=slot_habanero')">
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <div class="game-holder">
                            <div class="game-img">
                                <img title="CQ9" alt="CQ9"
                                src="https://images.linkcdn.cloud/global/banner/cq9.jpg">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">CQ9</div>
                                <div class="game-links main-sekarang-alert">
                                <a class="btn-custom" href="javascript:;" onclick="gameMaintenance('slot_cq9', '?page=slot_cq9')">
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <div class="game-holder">
                            <div class="game-img">
                                <img title="TOPTREND" alt="TOPTREND"
                                src="https://images.linkcdn.cloud/global/banner/top_trend_gaming.jpg" style="height: 50px">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">TOPTREND</div>
                                <div class="game-links main-sekarang-alert">
                                <a class="btn-custom" href="javascript:;" onclick="gameMaintenance('slot_toptrend', '?page=slot_toptrend')">
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <div class="game-holder">
                            <div class="game-img">
                                <img title="DREAMTECH" alt="DREAMTECH"
                                src="<?php echo $urlweb?>/uploads/provider/dreamtech.png" style="height: 50px">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">DREAMTECH</div>
                                <div class="game-links main-sekarang-alert">
                                <a class="btn-custom" href="javascript:;" onclick="gameMaintenance('slot_dreamtech', '?page=slot_dreamtech')">
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <div class="game-holder">
                            <div class="game-img">
                                <img title="BOOONGO" alt="BOOONGO" src="<?php echo $urlweb?>/uploads/provider/booongo.png">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">BOOONGO</div>
                                <div class="game-links main-sekarang-alert">
                                <a class="btn-custom" href="javascript:;" onclick="gameMaintenance('slot_booongo', '?page=slot_booongo')">
                                        Main Sekarang</a>
                                </div>
                            </div>
                        </div>

                        <div class="game-holder">
                            <div class="game-img">
                                <img title="PLAYSON" alt="PLAYSON"
                                src="<?php echo $urlweb?>/uploads/provider/playson.png">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">PLAYSON</div>
                                <div class="game-links main-sekarang-alert">
                                <a class="btn-custom" href="javascript:;" onclick="gameMaintenance('slot_playson', '?page=slot_playson')">
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>

                        <div class="game-holder">
                            <div class="game-img">
                                <img title="EVOPLAY" alt="EVOPLAY"
                                src="<?php echo $urlweb?>/uploads/provider/evoplay.png">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">EVOPLAY</div>
                                <div class="game-links main-sekarang-alert">
                                <a class="btn-custom" href="javascript:;" onclick="gameMaintenance('slot_evoplay', '?page=slot_evoplay')">
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                         <div class="game-holder">
                            <div class="game-img">
                                <img title="REELKINGDOM" alt="REELKINGDOM"
                                src="<?php echo $urlweb?>/uploads/provider/reelkingdom.png" style="height: 50px">
                            </div>
                            <div class="game-bottom">
                                <div class="game-name">REELKINGDOM</div>
                                <div class="game-links main-sekarang-alert">
                                <a class="btn-custom" href="javascript:;" onclick="gameMaintenance('slot_reelkingdom', '?page=slot_reelkingdom')">
                                    Main Sekarang</a>
                                </div>
                            </div>
                        </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</main>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    function gameMaintenance(gameCode, url) {
        if (gameMaintenanceStatus[gameCode] === '1') {
            Swal.fire({
                title: 'Maintenance',
                text: 'Game ini sedang dalam perbaikan. Harap coba lagi nanti.',
                icon: 'warning',
                confirmButtonText: 'OK'
            });
        } else {
            window.location.href = url;
        }
    }
</script>