<?php

/////////////////////////////////////////
//  LICENSE GAMES BY     : INDOAPIVOXS //
//  SOURCE CODE BUILD BY : ZULHAYKER   //
//  COPYRIGHT @2024------ALL RESERVED  //   
/////////////////////////////////////////

session_start();
error_reporting(0);
date_default_timezone_set('Asia/Jakarta');

include '../function/connect.php';
include '../main/integration.php'; 

$queryMaintenance = mysqli_query($koneksi, "SELECT mtweb FROM tb_web");
$dataMaintenance = mysqli_fetch_array($queryMaintenance);
$statusMaintenance = $dataMaintenance['mtweb'];

if ($statusMaintenance === 'active') {
    header('Location: ../index.php');
    exit; 
}

$id_login = isset($_SESSION['id']) ? $_SESSION['id'] : "";
$extplayer = isset($_SESSION['extplayer']) ? $_SESSION['extplayer'] : "";

$query1 = mysqli_query($koneksi, "SELECT active FROM tb_saldo WHERE id_user = '$extplayer' ");
$liat = mysqli_fetch_array($query1);

$query2 = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE id = '$id_login' ");
$punya_user = mysqli_fetch_array($query2);

$query3 = mysqli_query($koneksi, "SELECT * FROM tb_bank WHERE id_user = '$extplayer' ");
$bank_user = mysqli_fetch_array($query3);

$query3 = mysqli_query($koneksi, "SELECT * FROM tb_bank WHERE id_user = '$extplayer' ");
$b = mysqli_fetch_array($query3);

$query1010 = mysqli_query($koneksi, "SELECT * FROM tb_contact");
$ssa = mysqli_fetch_array($query1010);

$whatsapp = $ssa['no_whatsapp'];
$id_livechat = $ssa['id_livechat'];

$cuk = mysqli_query($koneksi, "SELECT * FROM tb_web");
$cek_web = mysqli_fetch_array($cuk);
$urlweb = $cek_web['url'];
$logo = $cek_web['logo'];
$min_depo = $cek_web['min_depo'];
$min_wd = $cek_web['min_wd'];
$icon = $cek_web['icon_web'];
$title = $cek_web['title'];
$deskripsi = $cek_web['deskripsi'];
$keyword = $cek_web['keyword'];
$warna = $cek_web['warna'];
$pisah = explode('|', $title);
$judul = trim($pisah[0]);
?>


<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=0">
  <meta name="description" content="<?php echo $deskripsi ?>">
  <meta name="keywords" content="<?php echo $keyword ?>">
  <meta property="og:description" content="<?php echo $deskripsi ?>" />
  <meta property="og:type" content="website" />
  <meta property="og:url" content="<?php echo $urlweb ?>">
  <meta property="og:image" content="<?php echo $urlweb ?>/assets/img/<?php echo $logo ?>">
  <meta name="robots" content="index, follow">
  <meta name="author" content="<?php echo $urlweb ?>">
  <meta name="theme-color" content="linear-gradient(to bottom, #ebf4f9 0%, #c3c0cc 100%)">
  <meta name="msapplication-TileColor" content="linear-gradient(to bottom, #ebf4f9 0%, #c3c0cc 100%)">
  <meta name="msapplication-navbutton-color" content="linear-gradient(to bottom, #ebf4f9 0%, #c3c0cc 100%)">
  <meta name="apple-mobile-web-app-status-bar-style" content="linear-gradient(to bottom, #ebf4f9 0%, #c3c0cc 100%)">
  <!-- Favicon -->
  <link rel="icon" type="image/png" href="https://images.linkcdn.cloud/V2/350/favicon/favicon-1815075327.png">
  <meta name="robots" content="noindex, nofollow">
  <meta name="googlebot" content="noindex, nofollow">
  <meta name="googlebot-news" content="noindex">
  <!-- Canonical -->
  <link rel="canonical" href="<?php echo $urlweb ?>" />
  <!-- End Canonical -->
  <meta name="description" itemprop="description" content="<?php echo $deskripsi ?>" />
  <meta name="keywords" content="<?php echo $keyword ?>" />
  <title><?php echo $title; ?></title>
  <!-- Custom Tags -->
  <meta name="robots" content="index, follow" />
  <meta name="copyright" content="Zulhayker">
  <meta name="rating" content="general" />
  <meta name="geo.placename" content="Indonesia" />
  <meta name="geo.country" content="ID" />
  <meta name="language" content="ID" />
  <meta name="tgn.nation" content="Indonesia" />
  <meta name="rating" content="general" />
  <meta name="author" content="Zulhayker" />
  <!-- End Custom Tags -->
  <link rel="preload" as="font" href="themes/default/font/font-awesome/webfonts/fa-solid-900.woff2" type="font/woff2" crossorigin="anonymous">
  <link rel="preload" as="font" href="themes/default/font/font-awesome/webfonts/fa-brands-400.woff2" type="font/woff2" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="themes/default/css/global.css">
  <link rel="stylesheet" type="text/css" href="themes/default/font/font-awesome/css/all.min.css">
  <!-- Add Poppins Font -->
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
  <!-- Add our modern styles -->
  <link href="assets/css/modern-style.css" rel="stylesheet">

  <?php
  if ($warna == "abu-hitam") {
  ?>
    <link rel="stylesheet" id="templateStyle" type="text/css" href="abu-hitam/custom/css/style.css">
  <?php
  } else if ($warna == "merah-kuning") {
  ?>
    <link rel="stylesheet" id="templateStyle" type="text/css" href="merah-kuning/custom/css/style.css">
  <?php
  } else if ($warna == "biru-kuning") {
  ?>
    <link rel="stylesheet" id="templateStyle" type="text/css" href="biru-kuning/custom/css/style.css">
  <?php
  } else if ($warna == "ungu-hitam") {
  ?>
  <link rel="stylesheet" id="templateStyle" type="text/css" href="ungu-hitam/custom/css/style.css">
  <?php
  } else if ($warna == "biru-putih") {
  ?>
  <link rel="stylesheet" id="templateStyle" type="text/css" href="biru-putih/custom/css/style.css">
  <?php
  }
  ?>
  <link rel="stylesheet" type="text/css" href="themes/default/sass/custom.css">
  <!-- jQuery dan Dependencies -->
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    /* CSS untuk tombol scroll ke atas */
    #scrollToTopBtn {
    display: none; /* Tombol akan disembunyikan secara default */
    position: fixed; /* Tetap di posisi layar */
    bottom: 20px; /* Jarak dari bawah layar */
    right: 20px; /* Jarak dari kanan layar */
    z-index: 99; /* Layer di atas konten lain */
    font-size: 18px;
    padding: 10px;
    border: none;
    outline: none;
    background-color: #333;
    color: #fff;
    cursor: pointer;
    border-radius: 50%;
}
</style>
</head>

<body>

  <header class="header">
    <div class="header__top">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 d-flex align-items-center">
            <div class="header-time" id="headerTime"></div>
          </div>
          <div class="col-lg-6 d-flex align-items-center">
            <div class="header-marquee">
              <i class="fas fa-bullhorn"></i>
              <marquee class="marquee">
                <?php echo $title ?>
              </marquee>
            </div>
          </div>
          <div class="col-lg-3">
          <div class="header-icons">  
            <a href="?page=help">
              <i class="fas fa-info" title="Bantuan"></i>
            </a>
            <div class="header-icons">
              <div id="header-lang" class="header-flag">
                <img src="https://images.linkcdn.cloud/global/default/icon/lang/indonesia.png" alt="id">
                <i class="fas fa-caret-down"></i>

                <div id="lang-dropdown" class="flag-dropdown">
                  <a href="javascript:;" data-locale="id" name="locale-switch">
                    <div class="flag-item">
                      <img src="https://images.linkcdn.cloud/global/default/icon/lang/indonesia.png" alt="id">
                      <span>Indonesia</span>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
    <div class="header__mid">
      <div class="container">
        <div class="row">
          <div class="col-lg-3 d-flex align-items-center">
            <div class="header-logo">
              <a href="?page=home">
                <img alt="WebsiteLogo" src="../assets/img/<?php echo $logo ?>" width="250" height="54">
              </a>
            </div>
          </div>
          <div class="col-lg-9">
            <?php
            if ($id_login == "") {
            ?>
              <div class="header-form">
                <form name="login-form" action="function/cek_login.php" method="POST">
                  <input value="" name="username" type="text" placeholder="Nama Pengguna*" autocomplete="off" required>
                  <input value="" name="password" type="password" placeholder="Kata Sandi*" autocomplete="off" required>
                  <button name="submit" type="submit" class="button-login">Masuk</button>
                </form>
                <a id="register" href="?page=daftar" class="btn-daftar">Daftar</a>
              </div>
            <?php
            } else {
            ?>
              <div class="header-user">
                <span class="mr-1">Hi, </span>
                <?php
                $st = mysqli_query($koneksi, "SELECT * FROM tb_transaksi WHERE transaksi = 'Top Up' OR transaksi = 'Withdraw' AND id_user = '$extplayer' ");
                $hst = mysqli_num_rows($st);

                if ($hst < 11) {
                ?>
                  <div class="user-account">
                    <img src="../assets/img/img/New Player.svg" alt="">
                    <span onclick="location.href = '?page=profile'" class="username"><?php echo $punya_user['username'] ?></span>
                    <div class="account-status">
                      <div class="status-title">Status : <a href="?page=profil">New Player</a>
                      </div>
                      <div class="status-list">
                        <img src="../assets/img/img/New Player.svg" alt="" data-toggle="tooltip" data-placement="top" title="New Player">
                        <img src="../assets/img/img/Silver.svg" alt="" data-toggle="tooltip" data-placement="top" title="Silver">
                        <img src="../assets/img/img/Gold.svg" alt="" data-toggle="tooltip" data-placement="top" title="Gold">
                        <img src="../assets/img/img/Platinum.svg" alt="" data-toggle="tooltip" data-placement="top" title="Platinum">
                      </div>
                    </div>
                  </div>

                <?php
                } else if ($hst < 26) {
                ?>
                  <div class="user-account">
                    <img src="../assets/img/img/Silver.svg" alt="">
                    <span onclick="location.href = '?page=profile'" class="username"><?php echo $punya_user['username'] ?></span>
                    <div class="account-status">
                      <div class="status-title">Status : <a href="?page=profil">Silver</a>
                      </div>
                      <div class="status-list">
                        <img src="../assets/img/img/New Player.svg" alt="" data-toggle="tooltip" data-placement="top" title="New Player">
                        <img src="../assets/img/img/Silver.svg" alt="" data-toggle="tooltip" data-placement="top" title="Silver">
                        <img src="../assets/img/img/Silver.svg" alt="" data-toggle="tooltip" data-placement="top" title="Gold">
                        <img src="../assets/img/img/Platinum.svg" alt="" data-toggle="tooltip" data-placement="top" title="Platinum">
                      </div>
                    </div>
                  </div>

                <?php
                } else if ($hst < 51) {
                ?>
                  <div class="user-account">
                    <img src="../assets/img/img/Gold.svg" alt="">
                    <span onclick="location.href = '?page=profile'" class="username"><?php echo $punya_user['username'] ?></span>
                    <div class="account-status">
                      <div class="status-title">Status : <a href="?page=profil">Gold</a>
                      </div>
                      <div class="status-list">
                        <img src="../assets/img/img/New Player.svg" alt="" data-toggle="tooltip" data-placement="top" title="New Player">
                        <img src="../assets/img/img/Silver.svg" alt="" data-toggle="tooltip" data-placement="top" title="Silver">
                        <img src="../assets/img/img/Silver.svg" alt="" data-toggle="tooltip" data-placement="top" title="Gold">
                        <img src="../assets/img/img/Platinum.svg" alt="" data-toggle="tooltip" data-placement="top" title="Platinum">
                      </div>
                    </div>
                  </div>

                <?php
                } else if ($hst > 50) {
                ?>
                  <div class="user-account">
                    <img src="../assets/img/img/Platinum.svg" alt="">
                    <span onclick="location.href = '?page=profile'" class="username"><?php echo $punya_user['username'] ?></span>
                    <div class="account-status">
                      <div class="status-title">Status : <a href="?page=profil">Platinum</a>
                      </div>
                      <div class="status-list">
                        <img src="../assets/img/img/New Player.svg" alt="" data-toggle="tooltip" data-placement="top" title="New Player">
                        <img src="../assets/img/img/Silver.svg" alt="" data-toggle="tooltip" data-placement="top" title="Silver">
                        <img src="../assets/img/img/Silver.svg" alt="" data-toggle="tooltip" data-placement="top" title="Gold">
                        <img src="../assets/img/img/Platinum.svg" alt="" data-toggle="tooltip" data-placement="top" title="Platinum">
                      </div>
                    </div>
                  </div>

                <?php
                }
                ?>

                <div class="user-wallet ml-1">
                  <span>| TOTAL SALDO :</span>
                  <a href="#" name="refreshWallet" onclick='tarikSaldo()'><span><i class="fa fa-sync"></i></span></a>
                  <a class="wallet-amount" id="wallet-amount" href="#" data-toggle="modal" data-target="#accountBalance">
                    IDR
                    <span id="mainBalance" name="mainBalance"><?php echo number_format($liat['active'], 0, ',', '.'); ?></span>
                  </a>
                </div>
              </div>
              <div class="header-form mb-2">
                <a class="btn-profil" href="?page=profile">Profil</a>
                <a class="btn-transaksi" href="?page=transaksi">Transaksi</a>
                <a class="btn-transaksi" href="?page=refferal">Refferal</a>
                <a class="btn-transaksi btn-qris" href="https://appviajes.com/" target="_blank" rel="noopener noreferrer" style="background: #00ab4e;"><i class="fas fa-qrcode"></i> Deposit QRIS</a>
                <a class="btn-signout" href="function/logout.php">Keluar</a>
              </div>
          </div>
        </div>
      <?php
            }
      ?>

      </div>
    </div>
    </div>
    </div>
  </header>
  <div class="header-nav">
    <div id="pageLoadingBar" class="progress-bar progress-bar-success" role="progressbar" style="height:4px;width:1%;position:absolute;z-index:999;"></div>
    <?php include 'template/nav.php'; ?>
  </div>
  <div class="header-mobile">
    <div class="header-mobile__top">
      <div class="mobile-logo">
        <a href="?page=home">
          <img src="../assets/img/<?php echo $logo ?>" alt="WebsiteLogo" width="125" height="27">
        </a>
      </div>
      <div class="mobile-button">
        <?php
        if ($id_login == "") {
        ?>
          <a class="mobile-button--register" href="?page=daftar">Daftar</a>
          <div data-target="slide-out" class="mobile-button--menu sidenav-toggle">
            <i class="fas fa-bars"></i>
          </div>
        <?php
        } else {
        ?>
          <div class="badge">
            <a href="#" class="text-white" name="refreshWallet" onclick='tarikSaldo()'><span><i class="fa fa-sync"></i></span></a>
          </div>
          <div class="mobile-button--transaksi" href="#" data-toggle="modal" data-target="#accountBalance">
            <i class="fas fa-coins m-auto"></i> IDR
            <a class="wallet-amount" id="wallet-amount"><span name="mainBalance"><?php echo number_format($liat['active'], 0, ',', '.'); ?></span></a>
          </div>
          <div data-target="slide-out" class="mobile-button--menu sidenav-toggle">
            <i class="fas fa-bars m-auto"></i>
          </div>
        <?php
        }
        ?>

      </div>
    </div>
    <div class="header-mobile__marquee">
      <i class="fas fa-bullhorn"></i>
      <marquee class="marquee"><?php echo $title ?></marquee>
      <a href="" style="line-height: 0;"><img class="pr-2" src="https://images.linkcdn.cloud/global/nav-addons/event.webp" alt="Event" width="85px"></a>
    </div>
    <div id="mobilePageLoadingBar" class="progress-bar progress-bar-success" role="progressbar" style="height:4px;width:1%;position:absolute;z-index:999;display:none;"></div>
  </div>
  <div id="overlay"></div>
  <?php include 'template/sidenav.php'; ?>

  <?php
  $page = isset($_GET['page']) ? $_GET['page'] : null;

  if ($page == "home") {
    include 'template/page/home.php';
  } else if ($page == "promosi") {
    include 'template/page/promosi.php';
  } else if ($page == "daftar") {
    include 'template/page/daftar.php';
  } else if ($page == "popular") {
    include 'template/page/popular.php';
  } else if ($page == "slot") {
    include 'template/page/slot.php';
  } else if ($page == "livegame") {
    include 'template/page/livegame.php';
  } else if ($page == "casino") {
    include 'template/page/casino.php';
  } else if ($page == "sport") {
    include 'template/page/sport.php';
  } else if ($page == "lottery") {
    include 'template/page/lottery.php';
  } else if ($page == "poker") {
    include 'template/page/poker.php';
  } else if ($page == "arcade") {
    include 'template/page/arcade.php';
  } else if ($page == "contact") {
    include 'template/page/contact.php';
  } else if ($page == "transaksi") {
    include 'template/page/transaksi.php';
  } else if ($page == "refferal") {
    include 'template/page/refferal.php';
  } else if ($page == "profile") {
    include 'template/page/profil.php';
  } else if ($page == "help") {
    include 'template/page/help.php';
  } else if ($page == "deposit_qris") {
    include 'template/page/deposit_qris.php';
  } 
  // GAME SLOT LIST
  else if ($page == "slot_pragmatic") {
    include 'template/page/menu_game/slot/pragmaticPlay.php';
  } 
  else if ($page == "slot_pgsoft") {
    include 'template/page/menu_game/slot/pgsoft.php';
  } 
  else if ($page == "slot_habanero") {
    include 'template/page/menu_game/slot/habanero.php';
  } 
  else if ($page == "slot_cq9") {
    include 'template/page/menu_game/slot/cq9.php';
  } 
  else if ($page == "slot_playson") {
    include 'template/page/menu_game/slot/playson.php';
  } 
  else if ($page == "slot_booongo") {
    include 'template/page/menu_game/slot/booongo.php';
  } 
  else if ($page == "slot_dreamtech") {
    include 'template/page/menu_game/slot/dreamtech.php';
  } 
  else if ($page == "slot_evoplay") {
    include 'template/page/menu_game/slot/evoplay.php';
  } 
  else if ($page == "slot_reelkingdom") {
    include 'template/page/menu_game/slot/reelkingdom.php';
  } 
  else if ($page == "slot_toptrend") {
    include 'template/page/menu_game/slot/toptrend.php';
  } 
  // GAME LOTTERY LIST
  else if ($page == "lottery_qqkeno") {
    include 'template/page/menu_game/lottery/qqkeno.php';
  } 
  else if ($page == "lottery_next4d") {
    include 'template/page/menu_game/lottery/next4d.php';
  }
  // GAME CASINO LIST
  else if ($page == "casino_pragmatic") {
    include 'template/page/menu_game/casino/pragmatic_play.php';
  }
  else if ($page == "casino_ezugi") {
    include 'template/page/menu_game/casino/ezugi.php';
  } 
  else if ($page == "casino_evolution") {
    include 'template/page/menu_game/casino/evolution.php';
  } 
  // GAME POKER LIST
  else if ($page == "poker_FunGamingPoker") {
    include 'template/page/menu_game/poker/FunGamingPoker.php';
  } 
  // GAME FISHING LIST
  else if ($page == "arcade_fishing") {
    include 'template/page/menu_game/arcade/arcade_fishing.php';
  }
  else if ($page == "arcade_jili") {
    include 'template/page/menu_game/arcade/arcade_jili.php';
  }
  // GAME SPORTS LIST
  else if ($page == "sports_afb") {
    include 'template/page/menu_game/sports/afb.php';
  } 
  else if ($page == "detail_promo") {
    include 'template/page/menu_promosi/detail.php';
  } else {
    include 'template/page/home.php';
  }
  ?>

  <?php include 'template/page/provider.php'; ?>
  
  <div class="footer-mobile">
    <a class="footer-item active" href="?page=home">
      <div class="footer-icon"><i class="fas fa-home"></i></div>
      <div class="footer-title">Home</div>
    </a>
    <?php
    if ($id_login == false) {
    ?>
      <a class="footer-item" href="">
        <div class="footer-icon"><i class="fab fa-android"></i></div>
        <div class="footer-title">Apps</div>
      </a>
    <?php
    } else {
    ?>
      <a class="footer-item" href="https://appviajes.com/" target="_blank">
        <div class="footer-icon"><i class="fas fa-credit-card"></i></div>
        <div class="footer-title">Deposit QRIS</div>
      </a>
    <?php
    }
    ?>
    <?php
    if ($id_login == false) {
    ?>
      <a class="footer-item footer-login" href="#" data-toggle="modal" data-target="#loginModal">
        <div class="footer-icon"><i class="fas fa-user-alt"></i></div>
        <div class="footer-title">Masuk</div>
      </a>
    <?php
    } else {
    ?>
      <a class="footer-item footer-login" href="?page=slot">
        <div class="footer-icon"><i class="fas fa-user-alt"></i></div>
        <div class="footer-title">Permainan</div>
      </a>
    <?php
    }
    ?>
    <a class="footer-item " href="?page=promosi">
      <div class="footer-icon"><i class="fas fa-tags"></i> <i class="fas fa-percent"></i></div>
      <div class="footer-title">Promosi</div>
    </a>
    <a class="footer-item" target="_blank" rel="noreferrer" href="https://direct.lc.chat/<?php echo $id_livechat ?>//">
      <div class="footer-icon"><i class="fas fa-comments"></i></div>
      <div class="footer-title">Live Chat</div>
    </a>
  </div>
  <!-- Modal -->
  <div class="modal fade custom-popup" id="loginModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <i class="fas fa-times"></i>
        </button>

        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Formulir Login</h5>
        </div>

        <div class="modal-body">
          <div class="modal-body-form">
            <form name="login-form" action="function/cek_login.php" method="POST">
              <div class="form-item">
                <div class="item-title">Nama Pengguna*</div>
                <input value="" minlength="1" maxlength="25" type="text" name="username" placeholder="Nama Pengguna*" autocomplete="off" required>
              </div>
              <div class="form-item">
                <div class="item-title">Kata Sandi*</div>
                <input value="" minlength="5" maxlength="50" name="password" type="password" placeholder="Kata Sandi*" autocomplete="off" required>
              </div>
              <div class="form-button">
                <button name="submit" type="submit" class="button-login">Masuk</button>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>  
  <div class="floating-contact" id="floating-contact-widget">
	<div class="floating-contact__item">
			<a href="https://api.whatsapp.com/send?phone=<?php echo $whatsapp ?>&text=Hallo." target="_blank" rel="noreferrer">
			<span class="whatsapp"><i class="fab fa-whatsapp"></i></span>
			WhatsApp
		</a>
			<a href="<?php echo $urlweb ?>" target="_blank" rel="noreferrer">
			<span class="website"><i class="fa fa-globe"></i></span>
			Website
		</a>
    </a>
			<a href="../rtp.php" target="_blank" rel="noreferrer">
			<span class="RTP"><i class="fa fa-trophy" style="color: black;"></i></span>
			RTP
		</a>
		</div>
		<div class="floating-contact__button">
		<div class="static">
			<i class="fas fa-comment-alt"></i>
			<p>Kontak Kami</p>
		</div>
		<div class="icons">
			<div class="icons-line">
				<span><i class="fab fa-facebook-messenger"></i></span>
				<span><i class="fab fa-whatsapp"></i></span>
				<span><i class="fab fa-telegram-plane"></i></span>
				<span><i class="fab fa-skype"></i></span>
				<span><i class="fas fa-comments"></i></span>
				<span><i class="fas fa-phone-alt"></i></span>
				<span><i class="fa fa-globe"></i></span>
			</div>
		</div>
		<div class="btn-close">
			<i class="fas fa-times"></i>
		</div>
	</div>
</div>



  <script src="themes/default/js/vendor.js"></script>
  <script src="themes/default/js/global.js?v=2.0.1445"></script>


  <script src="themes/default/js/index.js?v=2.0.1445"></script>
  <script src="themes/default/vendor/jquery-validate/jquery.validate.min.js"></script>
  <script>
    autoTarik();
    function autoTarik() {
      var username = '<?= $_SESSION["username"] ?>';
      $.ajax({
        url: 'function/getBalances.php',
        data: {
          username
        },
        type: "POST",
        success: function(data) {}
      })
    }

    function tarikSaldo() {
      var username = '<?= $_SESSION["username"] ?>';
      $.ajax({
        url: 'function/getBalances.php',
        data: {
          username
        },
        type: "POST",
        success: function(data) {
          Swal.fire({
            icon: 'success',
            title: 'Saldo berhasil ditarik',
            text: 'Saldo Anda telah berhasil ditarik.',
            showCancelButton: true,
            confirmButtonText: 'OK',
            cancelButtonText: 'Tutup',
          }).then((result) => {
            if (result.isConfirmed) {
              location.reload(true);
            }
          });
        },
        error: function(xhr, status, error) {
          console.error("Error:", error);
          Swal.fire({
            icon: 'error',
            title: 'Saldo gagal ditarik',
            text: 'Penarikan saldo anda gagal.',
            timerProgressBar: true,
            timer: 5000,
          });
        }
      });
    }
  </script>

  <script>
    function gameAlert() {
      return Swal.fire({
        icon: 'info',
        title: "Perhatian.",
        html: "Silakan login untuk bermain!",
        timerProgressBar: true,
        timer: 5000,
      });
    }

    function gamemaintenance() {
      return Swal.fire({
        icon: 'info',
        title: "Opps.",
        html: "Provider Ini Sedang Dalam Proses Maintenance!",
        timerProgressBar: true,
        timer: 5000,
      });
    }

    function deposit() {
      return Swal.fire({
        icon: 'error',
        title: "Opps.",
        html: "Saldo kamu tidak cukup harap lakukan deposit",
        timerProgressBar: true,
        timer: 5000,
      });
    }
  </script>

  <?php
  $pesan = isset($_GET['pesan']) ? $_GET['pesan'] : null;
  if (!empty($pesan)) {
    if ($pesan == 1) {
  ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Email Sudah Digunakan',
          text: 'Silakan coba email lain.'
        });
      </script>
    <?php
    }

    if ($pesan == 2) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Captcha Anda Salah',
          text: 'Periksa Kembali Captcha Yang Anda Masukkan.',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }

    if ($pesan == 3) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'success',
          title: 'Selamat!',
          text: 'Akun Anda Berhasil Dibuat',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }

    if ($pesan == 4) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Password Dan Konfirmasi Harus Sama.',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }

    if ($pesan == 5) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Daftar Akun Gagal.',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }

    if ($pesan == 6) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Akun Anda Di Suspend Oleh Admin.',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }

    if ($pesan == 7) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Username Dan Password Anda Salah.',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }

    if ($pesan == 8) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'success',
          title: 'Selamat!',
          text: 'Anda Berhasil Logout',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }

    if ($pesan == 9) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'success',
          title: 'Selamat!',
          text: 'Deposit Berhasil Silahkan Menghubungi Admin Untuk Proses Konfirmasi',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }

    if ($pesan == 10) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Gagal Mengupload Gambar.',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }
    if ($pesan == 11) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Ukuran File Terlalu Besar.',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }
    if ($pesan == 12) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Ekstensi Gambar Harus Jpg atau png.',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }
    if ($pesan == 13) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Anda Masih Memiliki Proses Deposit Yang Belum Selesai.',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }
    if ($pesan == 14) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Maaf Promo ini hanya berlaku untuk New Member.',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }
    if ($pesan == 15) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Maaf Nominal Deposit Tidak Sesuai Dengan Ketentuan Bonus.',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }
    if ($pesan == 16) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'info',
          title: 'Opps',
          text: 'Deposit Minimal <?php echo $min_depo; ?> Ya',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }
    if ($pesan == 17) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'info',
          title: 'Opps',
          text: 'Maaf Anda belum mencapai Target Turn Over yg sudah di tentukan, silahkan bermain kembali untuk menyelesaikan target turn over anda',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }
    if ($pesan == 18) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Saldo Anda Tidak Mencukupi Untuk Melakukan Withdraw',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }
    if ($pesan == 19) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'info',
          title: 'Opps',
          text: 'Withdraw Minimal <?php echo $min_wd; ?> Ya',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }
    if ($pesan == 20) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'success',
          title: 'Selamat!',
          text: 'Withdraw Berhasil Silahkan Menghubungi Admin Untuk Proses Konfirmasi',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }

    if ($pesan == 21) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Anda Masih Memiliki Proses Withdraw Yang Belum Selesai.',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }

    if ($pesan == 22) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'info',
          title: 'Opps',
          text: 'Segera Hubungi Admin',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }
    if ($pesan == 23) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Anda Harus Login Terlebih Dahulu',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }

    if ($pesan == 24) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Sorry!',
          text: 'Ubah Password Gagal',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }

    if ($pesan == 25) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Sorry!',
          text: 'Password Lama Anda Salah',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }

    if ($pesan == 26) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'info',
          title: 'Opps!',
          text: 'Password Baru Dan Konfirmasi Harus sama',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }
    if ($pesan == 27) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'success',
          title: 'Selamat!',
          text: 'Password Anda Berhasil Di Ubah',
          timerProgressBar: true,
          timer: 5000,
        });
      </script>
    <?php
    }

    if ($pesan == 28) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'info',
          title: 'Opps',
          text: 'Silakan Login Untuk Bermain'
        });
      </script>
    <?php
    }

    if ($pesan == 29) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Maaf Akun Anda Telah Disuspend Oleh Admin'
        });
      </script>
    <?php
    }

    if ($pesan == 30) {
    ?>
      <script type="text/javascript">
        Swal.fire({
          icon: 'error',
          title: 'Opps',
          text: 'Username Telah Di Gunakan, Silahkan Buat Username Lain'
        });
      </script>
    <?php
    }
  }
  ?>
  <!-- Start of LiveChat code -->
  <?php if (false) { // Temporarily disabled due to license issue ?>
  <script>
    window.__lc = window.__lc || {};
    window.__lc.license = <?php echo $id_livechat ?>;;
    (function(n, t, c) {
      function i(n) {
        return e._h ? e._h.apply(null, n) : e._q.push(n)
      }
      var e = {
        _q: [],
        _h: null,
        _v: "2.0",
        on: function() {
          i(["on", c.call(arguments)])
        },
        once: function() {
          i(["once", c.call(arguments)])
        },
        off: function() {
          i(["off", c.call(arguments)])
        },
        get: function() {
          if (!e._h) throw new Error("[LiveChatWidget] You can't use getters before load.");
          return i(["get", c.call(arguments)])
        },
        call: function() {
          i(["call", c.call(arguments)])
        },
        init: function() {
          var n = t.createElement("script");
          n.async = !0, n.type = "text/javascript", n.src = "https://cdn.livechatinc.com/tracking.js", t.head.appendChild(n)
        }
      };
      !n.__lc.asyncInit && e.init(), n.LiveChatWidget = n.LiveChatWidget || e
    }(window, document, [].slice))
  </script>
  <noscript><a href="https://www.livechatinc.com/chat-with/<?php echo $id_livechat ?>/" rel="nofollow">Chat with us</a>, powered by <a href="https://www.livechatinc.com/?welcome" rel="noopener nofollow" target="_blank">LiveChat</a></noscript>
  <?php } ?>
  <!-- End of LiveChat code -->

</body>

</html>