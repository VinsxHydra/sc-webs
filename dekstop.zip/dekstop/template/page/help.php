<main id="main-route">
    <div class="main-content help">
	<div class="container">
		<div class="page-header">Bantuan</div>
		<div class="help__content">
			<div class="row">
				<div class="col-lg-4">
					<div class="nav flex-column nav-pills" id="v-pills-tab" role="tablist" aria-orientation="vertical">
					<a class="nav-link active" name="helpType" id="v-pills-cara-bermain-tab" data-toggle="pill" href="#v-pills-cara-bermain" role="tab" aria-controls="v-pills-cara-bermain" aria-selected="true">Cara Bermain</a>
					<a class="nav-link" name="helpType" id="v-pills-faq-tab" data-toggle="pill" href="#v-pills-faq" role="tab" aria-controls="v-pills-faq" aria-selected="true">FAQ</a>
					<a class="nav-link" name="helpType" id="v-pills-info-khusus-tab" data-toggle="pill" href="#v-pills-info-khusus" role="tab" aria-controls="v-pills-info-khusus" aria-selected="true">Info Khusus</a>
					<a class="nav-link" name="helpType" id="v-pills-info-umum-tab" data-toggle="pill" href="#v-pills-info-umum" role="tab" aria-controls="v-pills-info-umum" aria-selected="false">Info Umum</a>
					<a class="nav-link" name="helpType" id="v-pills-regulation-tab" data-toggle="pill" href="#v-pills-regulation" role="tab" aria-controls="v-pills-regulation" aria-selected="true">Regulation</a>
					<a class="nav-link" name="helpType" id="v-pills-tentang-kami-tab" data-toggle="pill" href="#v-pills-tentang-kami" role="tab" aria-controls="v-pills-tentang-kami" aria-selected="false">Tentang Kami</a>
					</div>
				</div>
    <div class="col-lg-8">
    	<div class="tab-content" id="v-pills-tabContent">
    		<div class="tab-pane fade active show" name="helpDesc" id="v-pills-cara-bermain" role="tabpanel" aria-labelledby="v-pills-cara-bermain-tab">
    				<div class="help-header">Cara Bermain</div>
    												<div class="accordion help-accordion" id="accordionExample">
    					<div class="card">
    						<div class="card-header" id="headingOne">
    							<div class="help-toggle" data-toggle="collapse" data-target="#cara-bermain" aria-expanded="true" aria-controls="collapseOne">Cara Bermain</div>
    						</div>
    						<div id="cara-bermain" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
    							<div class="card-body">
    								<p>Langkah - Langkah Jika Anda lupa password login ID :<br><strong>Cara Pertama :</strong><br>1. Klik menu lupa password di sebelah kanan atas<br>2. Masukan user ID Anda dan Email yang terdaftar di&nbsp;<strong><?php echo $judul ?></strong>.<br>3. Buka Email Anda, masuk ke Inbox, lalu klik Reset Your Password<br>4. Anda akan langsung menuju menu Reset Password di dalam website, dan masukan Password Baru Anda, lalu tekan Submit<br><strong>(Minimal Password harus 8 Karakter)</strong><br>Menu ini dapat di lakukan di Komputer dan Handphone anda ( Tampilan Desktop )&nbsp;</p><p><strong>Cara Lain :&nbsp;</strong><br>* Klik menu Live Chat pada menu kanan bawah dan Anda bisa&nbsp;langsung bertanya dan akan di arahkan untuk bisa mendapatkan password baru anda<br>* Chat melalui Whatsapp&nbsp;<strong><?php echo $judul ?></strong>&nbsp;:<?php echo $whatsapp ?></p>
    								<p><em>Terakhir di Update : </em>
    									2023-12-03 14:30:54
    								</p>
    							</div>
    						</div>
    					</div>
    				</div>
															</div>
														<div class="tab-pane fade" name="helpDesc" id="v-pills-faq" role="tabpanel" aria-labelledby="v-pills-faq-tab">
								<div class="help-header">FAQ</div>
																<div class="accordion help-accordion" id="accordionExample">
									<div class="card">
										<div class="card-header" id="headingOne">
											<div class="help-toggle" data-toggle="collapse" data-target="#tidak-bisa-login" aria-expanded="true" aria-controls="collapseOne">Tidak Bisa Login</div>
										</div>
										<div id="tidak-bisa-login" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
											<div class="card-body">
												<p><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">Jika Anda tidak dapat Login ke&nbsp;<strong><?php echo $judul ?></strong>, Anda dapat mengikuti langkah langkah berikut ini&nbsp;</span><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">1.&nbsp;Klik Situs Resmi&nbsp;<strong><?php echo $judul ?></strong></span><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">2.&nbsp;Periksa nama penguna dan Sandi Anda.</span><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">3.&nbsp;Klik menu Live Chat pada menu kanan bawah (&nbsp;bisa langsung bertanya dan akan di arahkan oleh Customer Service 24 jam mengapa ID tidak bisa terbuka )</span></p>
												<p><em>Terakhir di Update : </em>
													2023-05-25 15:59:08
												</p>
											</div>
										</div>
									</div>
								</div>
															</div>
														<div class="tab-pane fade" name="helpDesc" id="v-pills-info-khusus" role="tabpanel" aria-labelledby="v-pills-info-khusus-tab">
								<div class="help-header">Info Khusus</div>
																<div class="accordion help-accordion" id="accordionExample">
									<div class="card">
										<div class="card-header" id="headingOne">
											<div class="help-toggle" data-toggle="collapse" data-target="#memo" aria-expanded="true" aria-controls="collapseOne">Memo</div>
										</div>
										<div id="memo" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
											<div class="card-body">
												<p><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">Ini merupakan salah satu fitur untuk membantu member berkomunikasi dengan CS yang sedang bertugas.</span><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">Untuk bisa menggunakan fitur Memo, Silahkan Login terlebih dahulu.&nbsp;</span><strong>( Menu&nbsp;MEMO&nbsp;ada di bagian atas)</strong><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">Klik Add Memo untuk mengirimkan pesan, dan balasan pesan dari CS akan masuk ke menu Inbox.</span><br><strong>LAYANAN HOTLINE :&nbsp;WHATSAPP <?php echo $judul ?></strong></p>
												<p><em>Terakhir di Update : </em>
													2023-05-25 15:55:24
												</p>
											</div>
										</div>
									</div>
								</div>
															</div>
														<div class="tab-pane fade" name="helpDesc" id="v-pills-info-umum" role="tabpanel" aria-labelledby="v-pills-info-umum-tab">
								<div class="help-header">Info Umum</div>
																<div class="accordion help-accordion" id="accordionExample">
									<div class="card">
										<div class="card-header" id="headingOne">
											<div class="help-toggle collapsed" data-toggle="collapse" data-target="#cara-daftar" aria-expanded="false" aria-controls="collapseOne">Cara Daftar</div>
										</div>
										<div id="cara-daftar" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample" style="">
											<div class="card-body">
												<p>01. Tekan / Klik menu&nbsp;<a href="?page=daftar"><strong>DAFTAR</strong></a>.<br>02. Isi Kolom Username atau nama pengguna sesuai keinginan anda.<br>03. Isi Kolom password atau kata sandi yang anda inginkan.&nbsp;<strong>(Minimal 7 Karakter)</strong><br>04. Isi Kolom Konfirmasi Password atau isi dengan kata sandi yang anda buat di atas.<strong>&nbsp;(Minimal 7 Karakter)</strong><br>05. Isi kolom Email dengan alamat email aktif.&nbsp;<strong>(Diperlukan jika anda lupa password)</strong><br>06. Isi kolom Telepon dengan nomor telepon aktif.<br>07. Pilih Kolom Bank sesuai dengan Bank yang anda gunakan.<br>08. Isi kolom Nama sesuai rekening sesuai dengan Nama di buku tabungan anda.<br>09. Isi Nomor rekening yang valid atau benar.<br>10. Kosongkan Kolom Referal jika tidak ada.<br>11. Isi perintah I'm not a Robot sesuai yang di tampilkan<br>12. Ceklist atau centang *Saya telah berusia lebih dari 18 tahun dan telah membaca dan menerima syarat dan ketentuan yang dipasang di situs ini, peraturan pribadi dan aturan taruhan.<br>13. Klik Tombol Daftar</p><p><strong>SELAMAT ANDA BERHASIL BERGABUNG BERSAMA AGENSLOT68</strong></p>
												<p><em>Terakhir di Update : </em>
													2023-05-25 15:41:33
												</p>
											</div>
										</div>
									</div>
								</div>
																<div class="accordion help-accordion" id="accordionExample">
									<div class="card">
										<div class="card-header" id="headingOne">
											<div class="help-toggle" data-toggle="collapse" data-target="#cara-dapatkan-bonus" aria-expanded="true" aria-controls="collapseOne">Cara Dapatkan Bonus</div>
										</div>
										<div id="cara-dapatkan-bonus" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
											<div class="card-body">
												<p><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">Setiap Member Bisa Klaim Promo Bonus Yang Diberikan Oleh Pihak&nbsp;<strong><?php echo $judul ?></strong></span><br><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">Bagaimana Cara Mendapatkan Bonus Promo di&nbsp;<strong><?php echo $judul ?></strong>?</span><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">1. Anda wajib Memiliki Kredit Bermain ( Silakan Deposit via Bank Lokal / Pulsa Telkomsel , Axis , Xl / Bank Digital&nbsp;dan Bank Lain )</span><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">2. Silakan Login dan Menuju Menu&nbsp;</span><strong>TRANSFER - Dompet Utama</strong><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">3. Saat member wajib Pindah Credit dari Menu&nbsp;</span><strong>TRANSFER DOMPET UTAMA ke GAME</strong><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">&nbsp;akan ada pilihan PROMO</span><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">4. Member Bisa Memilih&nbsp;</span><strong>PROMO YANG SEDANG ADA DI PILIHAN PROMO</strong><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">.</span><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">5. Apabila member sudah Memilih Promo Maka Akan Terikat&nbsp;</span><strong>Ketentuan Promo dan Turn Over Target Promo</strong><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">&nbsp;Bonus baru bisa withdraw&nbsp;</span></p>
												<p><em>Terakhir di Update : </em>
													2023-05-25 15:42:34
												</p>
											</div>
										</div>
									</div>
								</div>
																<div class="accordion help-accordion" id="accordionExample">
									<div class="card">
										<div class="card-header" id="headingOne">
											<div class="help-toggle" data-toggle="collapse" data-target="#cara-deposit" aria-expanded="true" aria-controls="collapseOne">Cara Deposit</div>
										</div>
										<div id="cara-deposit" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
											<div class="card-body">
												<p><strong>PERHATIKAN DENGAN SEKSAMA NOMOR REKENING TUJUAN !&nbsp;</strong><br><br>Kami tidak memberikan toleransi apabila terjadi kesalahan transfer uang (Deposit) ke rekening yang tidak tertera di website&nbsp;<strong><?php echo $judul ?></strong>.<br><br>Minimal Deposit&nbsp;<strong><?php echo $judul ?>&nbsp;</strong>adalah Rp 10&nbsp; ( 10&nbsp;Ribu Rupiah )<br>Minimal Deposit PULSA&nbsp;<strong><?php echo $judul ?>&nbsp;</strong>adalah Rp 10&nbsp;( 10&nbsp;Ribu Rupiah&nbsp;)</p><p>1. Setelah login, klik&nbsp;<strong>TRANSAKSI</strong>&nbsp;pada bagian atas menu di halaman utama kami kemudian klik&nbsp;<strong>TAMBAH DANA</strong><br>2. Daftar nomor rekening tujuan kami yang aktif saat ini bisa dilihat di kolom&nbsp;<strong>PILIH AKUN BANK.</strong><br>Pilih Bank yang ingin anda gunakan Untuk tujuan Transfer/ Deposit .<br>3. Hubungi Customer Service kami melalui Live Chat untuk info bank online atau offline, setelah itu lakukan transfer dana ke rekening tujuan.<br>Apabila Bank sedang Offline diharapkan Deposit Ke Bank kami Yang Aktif (&nbsp;<strong>Silakan Tanya CS via Livechat / WhatsApp</strong>&nbsp;)<br>4. Setelah proses transaksi berhasil, silahkan dilanjutkan dengan mengisi Form Deposit dengan benar (&nbsp;<strong>setoran deposit 50.000, tulis Rp 50 ( 3 digit dihilangkan</strong>&nbsp;)<br>5. Tulis Keterangan pada Remark : Jam transfer dan Lampirkan Foto Bukti transfer .<br>6. Klik Submit Form Deposit.</p><p><br><strong>~ PERHATIAN ~</strong><br><br>APABILA DEPOSIT DENGAN PULSA HARAP MENGISI NO HP / KODE SN TRANSFER ANDA DI MENU REMARK / KETERANGAN !!<br><br>Metode Pembayaran yang diterima <strong><?php echo $judul ?></strong><br>M-banking / Mobile Banking<br>Internet Banking<br>Sms Banking<br>ATM<br>KlikPay BCA<br>Pulsa Telkomsel<br>Pulsa XL &amp; Axis<br>Pulsa Axis<br>APLIKASI E-WALLET ( DANA, OVO, LINKAJA, GOPAY, &nbsp;dll )</p>
												<p><em>Terakhir di Update : </em>
													2023-05-25 15:41:14
												</p>
											</div>
										</div>
									</div>
								</div>
																<div class="accordion help-accordion" id="accordionExample">
									<div class="card">
										<div class="card-header" id="headingOne">
											<div class="help-toggle" data-toggle="collapse" data-target="#cara-transfer-ke-bank-lain" aria-expanded="true" aria-controls="collapseOne">Cara Transfer ke Bank Lain</div>
										</div>
										<div id="cara-transfer-ke-bank-lain" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
											<div class="card-body">
												<p>Kami Menerima berbagai macam Pilihan BANK LAIN, termasuk BANK LOCAL, BANK DAERAH DAN BANK DIGITAL ( E-WALLET )&nbsp;Berbagai macam alternatif pengiriman lainnya<br>BANK<br>PERMATA<br>BANK&nbsp;<br>PANIN<br>BANK<br>BUKOPIN<br>BANK MEGA<br>BANK ACEK SYARIAH<br>BANK ANTAR DAERAH<br>BANK ARTHA GRAHA<br>BANK AGRIS<br>BANK BJB<br>BANK BKE<br>BANK BTPN<br>BANK BDS<br>BPD BANTEN<br>BPD BALI<br>BPD SUMUT<br>BPD JAMBI<br>BPD LAMPUNG<br>BPD MALUKU<br>DAN masih banyak lagi lainnya</p><p>* <strong><?php echo $judul ?></strong> Menyediakan layanan BANK LAIN untuk semua Penjuru NUSANTARA<br>* Wajib melakukan pendaftaran dengan menggunakan rekening BANK AKTIF, dan di samping nama REKENING GUNAKAN NAMA BANK&nbsp;</p><p>CONTOH&nbsp;&nbsp; &nbsp;: JONI&nbsp;( BANK SUMUT )<br>: FERDI&nbsp;( BANK MEGA )<br>: SISKA&nbsp;( BPD BALI )&nbsp;<br>*Untuk melakukan DEPOSIT, kami menyedikan rekening MANDIRI yang sudah terdaftar di menu SETORAN "BANK LAIN"<br>*Jika wd di atas 300 ribu, BIAYA transaksi akan di tanggung oleh pihak&nbsp;<strong><?php echo $judul ?></strong><br>*apabila WD di bawah 300 ribu, Biaya akan di potong saat melakukan WITHDRAW<br>CONTOH WD 100.000 BIAYA PENGIRIMAN 6500<br>Maka DANA yang akan di kirim hanya 93.500</p><p>Apabila ada pertanyaan atau ketentuan yang tidak di mengerti<br>bisa langsung bertanya ke&nbsp;<strong>CS kami yang melayani anda 1 X 24 JAM</strong></p>
												<p><em>Terakhir di Update : </em>
													2023-05-25 15:44:58
												</p>
											</div>
										</div>
									</div>
								</div>
															</div>
														<div class="tab-pane fade" name="helpDesc" id="v-pills-regulation" role="tabpanel" aria-labelledby="v-pills-regulation-tab">
								<div class="help-header">Regulation</div>
																<div class="accordion help-accordion" id="accordionExample">
									<div class="card">
										<div class="card-header" id="headingOne">
											<div class="help-toggle" data-toggle="collapse" data-target="#ganti-password" aria-expanded="true" aria-controls="collapseOne">Ganti Password</div>
										</div>
										<div id="ganti-password" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
											<div class="card-body">
												<p><strong>CARA MERUBAH atau MENGANTI PASSWORD di <?php echo $judul ?> :</strong><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">1. Silahkan login ID Anda terlebih dahulu.</span><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">2.&nbsp;Pilih / Klik menu&nbsp;PROFIL&nbsp;pada bagian atas</span><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">3. Setelah itu Masukan "Sandi lama / Password lama" anda =</span><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">4.&nbsp;Kemudian&nbsp;</span><strong>New Password&nbsp;dan&nbsp;Confirm Password</strong><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">&nbsp;&gt; Tulis&nbsp;Sandi Baru / Password Baru&nbsp;yang anda inginkan</span><br><span style="background-color:rgb(255,255,255);color:rgb(33,37,41);">4. Klik Submit untuk menyetujui pergantian Password yang baru</span></p>
												<p><em>Terakhir di Update : </em>
													2023-05-25 15:46:13
												</p>
											</div>
										</div>
									</div>
								</div>
															</div>
														<div class="tab-pane fade" name="helpDesc" id="v-pills-tentang-kami" role="tabpanel" aria-labelledby="v-pills-tentang-kami-tab">
								<div class="help-header">Tentang Kami</div>
																<div class="accordion help-accordion" id="accordionExample">
									<div class="card">
										<div class="card-header" id="headingOne">
											<div class="help-toggle" data-toggle="collapse" data-target="#cara-withdraw" aria-expanded="true" aria-controls="collapseOne">Cara Withdraw</div>
										</div>
										<div id="cara-withdraw" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample" style="">
											<div class="card-body">
												<p>Minimal Withdraw : &nbsp;Rp. 50&nbsp; ( 50.000 rupiah )<br><strong>KAMI HANYA AKAN TRANSFER DANA KE REKENING &nbsp;YANG SUDAH TERDAFTAR !&nbsp;</strong></p><p><strong>Dana dapat anda withdraw dari akun anda menggunakan metode berikut:</strong><br>1. Setelah login Klik&nbsp;<strong>TRANSAKSI</strong>&nbsp;pada bagian atas menu di halaman utama kami ,kemudian transfer dana yang ingin ditarik keluar dari Dompet Permainan ke Dompet Utama.<br>2. Setelah dana permainan semua terkumpul di&nbsp;<strong>DOMPET UTAMA ( MAIN WALLET )</strong>, klik Transaksi&nbsp;<strong>WITHDRAW</strong>&nbsp;Tarik Dana lalu masukkan jumlah yang ingin anda withdraw.</p><p>Dana akan dimasukan kedalam akun anda sesuai dengan yang anda minta setelah diverifikasi oleh Tim Keuangan kami. Verifikasi yang dilakukan oleh Tim Keuangan kami akan memakan waktu antara 5 -30 menit bergantung pada waktu pemrosesan masing-masing bank.<br><br>Mohon diingat kembali, kami tidak memperbolehkan member menggunakan akun rekening bank orang lain untuk melakukan Withdraw, jika terjadi hal tersebut maka akan kami lakukan refund/ Kembalikan ke dalam akun member.&nbsp;Untuk Member yang rekening nya tidak valid, maka semua credit nya tidak bisa di withdraw dan akan di kembalikan sebagai credit bermain.!</p><p><strong>HUBUNGI LIVECHAT&nbsp;KAMI :</strong><br>Layanan Livechat&nbsp;Mempermudah anda untuk&nbsp;CHECK Withdraw anda Lebih Cepat untuk diproses .</p>
												<p><em>Terakhir di Update : </em>
													2023-05-25 15:55:15
												</p>
											</div>
										</div>
									</div>
								</div>
																<div class="accordion help-accordion" id="accordionExample">
									<div class="card">
										<div class="card-header" id="headingOne">
											<div class="help-toggle" data-toggle="collapse" data-target="#hubungi-kami" aria-expanded="true" aria-controls="collapseOne">Hubungi Kami</div>
										</div>
										<div id="hubungi-kami" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
											<div class="card-body">
												<p>Hubungi Kami melalui&nbsp;<strong>LIVECHAT <?php echo $judul ?>&nbsp;</strong>atau bisa melalui Nomor&nbsp;<strong>WHATSAPP&nbsp;</strong>kami&nbsp;:&nbsp;</p><p style="text-align:center;"><strong>LIVECHAT <?php echo $judul ?> : </strong><a href="https://direct.lc.chat/<?php echo $id_livechat ?>//"><strong>https://direct.lc.chat/<?php echo $id_livechat ?></strong></a><strong>&nbsp;</strong></p><figure class="image image_resized" style="width:646px;"><img src="https://i.imgur.com/GITzPEo.png" alt=""></figure>
												<p><em>Terakhir di Update : </em>
													2023-05-25 15:58:14
												</p>
											</div>
										</div>
									</div>
								</div>
																<div class="accordion help-accordion" id="accordionExample">
									<div class="card">
										<div class="card-header" id="headingOne">
											<div class="help-toggle" data-toggle="collapse" data-target="#keamanan" aria-expanded="true" aria-controls="collapseOne">Keamanan</div>
										</div>
										<div id="keamanan" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
											<div class="card-body">
												 
												<p><em>Terakhir di Update : </em>
													2023-01-01 00:00:00
												</p>
											</div>
										</div>
									</div>
								</div>
																<div class="accordion help-accordion" id="accordionExample">
									<div class="card">
										<div class="card-header" id="headingOne">
											<div class="help-toggle" data-toggle="collapse" data-target="#penolakan" aria-expanded="true" aria-controls="collapseOne">Penolakan</div>
										</div>
										<div id="penolakan" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
											<div class="card-body">
												 
												<p><em>Terakhir di Update : </em>
													2023-01-01 00:00:00
												</p>
											</div>
										</div>
									</div>
								</div>
																<div class="accordion help-accordion" id="accordionExample">
									<div class="card">
										<div class="card-header" id="headingOne">
											<div class="help-toggle" data-toggle="collapse" data-target="#peraturan" aria-expanded="true" aria-controls="collapseOne">Peraturan</div>
										</div>
										<div id="peraturan" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample" style="">
											<div class="card-body">
												<figure class="image image_resized" style="width:323px;"><img src="<?php echo $urlweb?>/uploads/provider/rules.png"><p><span style="font-size:17px;"><strong>PERATURAN <?php echo $judul ?> :</strong></span></p><ul><li><span style="font-size:17px;">Setiap Member harus menyetujui Persyaratan dan Peraturan website SportsBook, Slot Online, Togel atau Casino dll sebelum melakukan pemasangan taruhan.</span></li><li><span style="font-size:17px;">Usia minimum untuk membuka account melalui <?php echo $judul ?> adalah 18 tahun.</span></li><li><span style="font-size:17px;">Setiap Member bertanggung jawab untuk menjaga kerahasiaan User ID dan Passwordnya.</span></li><li><span style="font-size:17px;">Setiap Member wajib memberikan Data terbaru dan Aktif, khususnya Nomor Handphone/ Whatsapp dan Rekening Bank.</span></li><li><span style="font-size:17px;">Setiap Deposit dan Withdraw, hanya diterima dan dikirimkan ke Rekening Bank terdaftar.</span></li><li><span style="font-size:17px;">Minimum Deposit &amp; Withdraw adalah ( Untuk Deposit Rp. 5.000,- &amp; Untuk Withdraw Rp. 50.000,-</span></li><li><span style="font-size:17px;">Permintaan Deposit &amp; Withdraw dapat dilakukan 24 jam sehari, 7 hari seminggu, 365 hari setahun.</span></li><li><span style="font-size:17px;"><strong>MAKSIMAL PEMBAYARAN UNTUK GRAND JACKPOT ADALAH 1 MILYAR RUPIAH ( IDR 1.000.000.000&nbsp;)</strong></span></li><li><span style="font-size:17px;">Selama Bank tidak sedang Offline atau maintenance, akan langsung diproses setelah member Konfirmasi.</span></li><li><span style="font-size:17px;">Demi Keamanan, <?php echo $judul ?> berhak menonaktifkan account yg telah 3 bulan tidak aktif dan saldo yg telah kosong.</span></li><li><span style="font-size:17px;">Management berhak menolak keanggotaan member yg tidak menaati peraturan yang berlaku.</span></li><li><span style="font-size:17px;">Info untuk semua para member setia <?php echo $judul ?>,jika terdapat pemalsuan data akun dan abnormal bet / kecurangan taruhan maka kemenangan anda akan di tarik oleh pihak <?php echo $judul ?> dan dana akan di kembalikan sesuai dengan nilai deposit anda.</span></li><li><span style="font-size:17px;">Mendaftar di <?php echo $judul ?> berarti setuju dengan semua Peraturan, Syarat dan Keputusan diatas.</span></li><li><span style="font-size:17px;">Jika membutuhkan bantuan dan informasi lebih lanjut bisa menghubungi kami di Livechat Resmi MPO76.</span></li></ul><p><span style="font-size:17px;"><strong>Livechat Resmi <?php echo $judul ?> : </strong></span><a href="https://direct.lc.chat/<?php echo $id_livechat ?>//"><span style="font-size:17px;"><strong>KLIK DISINI</strong></span></a></p>
												<p><em>Terakhir di Update : </em>
													2023-05-25 15:57:15
												</p>
											</div>
										</div>
									</div>
								</div>
															</div>
																		</div>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="main-content game">
    <div class="container">
    	<div class="game__seo">
    <div hidden="" id="title-seo">Panduan Turitorial Bermain Game Pulsa <?php echo $judul ?></div>
        <div class="seo-content showFooter">
                <p><span style="background-color:hsl(0,0%,0%);color:rgb(255,255,255);">Layanan Bantuan Resmi <?php echo $judul ?> Silahkan Chat ke Livechat Resmi kami di <?php echo $judul ?>. Terima Kasih</span></p>
            </div>
        </div>
    </div>
</div>
</main>