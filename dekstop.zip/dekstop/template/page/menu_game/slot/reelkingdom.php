<!-- Account Balance -->
<main id="main-route">
    <div class="main-content slot-game">
        <div class="container">
            <div class="slot-game__container">
                <div class="page-header">REELKINGDOM</div>
                <div class="component-pills-tab" id="game-filter">
                        <div class="filter-tab" onclick="filterGameSelection('all')">All Games</div>
                        <div class="filter-tab" onclick="filterGameSelection('video-slots')"> Video Slots
                        </div>
                        <div class="filter-tab" onclick="filterGameSelection('bonus-buy-slot-games')"> Bonus Buy Slot
                            Games
                        </div>
                        <div class="filter-tab" onclick="filterGameSelection('classic-slots')"> Classic Slots
                        </div>
                        <div class="slot-game__search-cont">
                            <div class="game-search">
                                <input class="form-control-sm" type="text" onkeyup="searchGames(this)"
                                    placeholder="Cari ...">
                                <a href="#" class="search-btn">
                                    <i class="fas fa-search"></i>
                                </a>
                            </div>
                        </div>
                    </div>
                <div class="slot-game-list">
                    <?php
                    $id_provider = 'REELKINGDOM';
                    $categories = 'slots';
                    $user = $_SESSION['username'];
                    $getUser = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE username = '$user'");
                    $infouser = mysqli_fetch_array($getUser);
                    $extplayer = $infouser['extplayer'];
                    $query = mysqli_query($koneksi, "SELECT * FROM tb_games WHERE game_provider = '$id_provider' AND game_type = '$categories' ");
                    function generateRandomRTP()
                    {
                        $minRTP = 80;
                        $maxRTP = 96;

                        // Menghasilkan nilai acak antara 80 dan 96
                        $randomRTP = rand($minRTP, $maxRTP);

                        return $randomRTP;
                    }
                    $randomRTP = generateRandomRTP();

                    while ($row = mysqli_fetch_array($query)) {
                        if (isset($_SESSION['username'])) {
                          $que = mysqli_query($koneksi, "SELECT * FROM tb_user WHERE extplayer = '$extplayer' AND status_game = 'offgame' ");

                          $cek = mysqli_num_rows($que);

                          if($cek > 0){
                            $link_url = 'index.php?pesan=22';
                        }else{
                            if ($id_login == '') {
                                $link_url = 'index.php?pesan=28';
                            }else{
                                $link_url = $urlweb . "/main/PlayGame.php?p=".$extplayer."&provider=".$row['game_provider']."&id=".$row['game_code'];
                            }

                        }
                        ?>
                        <div class="slot-game-item slot-tg" style="display: block;">
                            <div class="slot-game-img">
                                <img src="<?php echo $row['game_image'] ?>" style="">
                            </div>
                            <div class="slot-game-name"><?php echo $row['game_name']; ?></div>
                            <div class="slot-game-hover">
                                <a class="main sekarang main-sekarang-alert" href="<?php echo $link_url ?>">
                                    Main Sekarang
                                </a>
                            </div>
                        </div>

                        <?php
                    } else {
                        ?>
                        <div class="slot-game-item slot-tg xbonus-buy-slot-games show" style="">
                            <div class="slot-game-img">
                                <img src="<?php echo $row['game_image'] ?>" style="">
                            </div>
                            <div class="slot-game-name"><?= $row['game_name'] ?></div>
                            <div class="progress baradjust">
                                <?php
                                $randomRTP = generateRandomRTP();
                                $progressColor = '';
                                if ($randomRTP >= 80) {
                                    $progressColor = 'bg-success'; // warna hijau untuk RTP di atas atau sama dengan 80
                                } elseif ($randomRTP >= 70) {
                                    $progressColor = 'bg-primary'; // warna biru untuk RTP di atas atau sama dengan 70
                                } else {
                                    $progressColor = 'bg-warning'; // warna kuning untuk RTP di bawah 70
                                }
                                ?>
                                <div class="progress-bar progress-bar-striped progress-bar-animated <?php echo $progressColor; ?>" id="progress-rtp" role="progressbar" style="width:<?= $randomRTP ?>%;" aria-valuenow="<?= $randomRTP ?>" aria-valuemin="0" aria-valuemax="100">
                                    RTP <?php echo $randomRTP; ?>%
                                </div>
                            </div>
                            <div class="progress baradjust">
                                <?php
                                $randomRTP = generateRandomRTP();
                                $progressColor = '';
                                if ($randomRTP >= 80) {
                                    $progressColor = 'bg-success'; // warna hijau untuk RTP di atas atau sama dengan 80
                                } elseif ($randomRTP >= 70) {
                                    $progressColor = 'bg-primary'; // warna biru untuk RTP di atas atau sama dengan 70
                                } else {
                                    $progressColor = 'bg-warning'; // warna kuning untuk RTP di bawah 70
                                }
                                ?>
                                <div class="progress-bar progress-bar-striped progress-bar-animated <?php echo $progressColor; ?>" id="progress-rtp" role="progressbar" style="width:<?= $randomRTP ?>%;" aria-valuenow="<?= $randomRTP ?>" aria-valuemin="0" aria-valuemax="100">
                                    RTP <?php echo $randomRTP; ?>%
                                </div>
                            </div>
                            <div class="slot-game-hover">
                                <a class="main sekarang main-sekarang-alert" onclick='gameAlert()'>
                                    Main Sekarang
                                </a>
                            </div>
                        </div>
                    <?php }
                } ?>
            </div>
        </div>
    </div>
</div>
<script>
    function filterGameSelection(category) {
        var slotGameItems = document.querySelectorAll('.slot-game-item'); // Ambil semua elemen dengan kelas slot-game-item

        slotGameItems.forEach(function(gameItem) {
            if (category === 'all') { // Jika kategori adalah 'all', tampilkan semua game
                gameItem.style.display = 'block';
            } else {
                var gameType = gameItem.dataset.category; // Ambil data kategori game dari atribut dataset
                if (gameType === category) { // Jika kategori game cocok dengan kategori yang dipilih
                    gameItem.style.display = 'block'; // Tampilkan game
                } else {
                    gameItem.style.display = 'none'; // Sembunyikan game jika kategori tidak cocok
                }
            }
        });
    }
</script>
<script>
    function searchGames(input) {
        var searchTerm = input.value.toLowerCase(); // Konversi input ke huruf kecil
        var slotGameList = document.querySelectorAll('.slot-game-item'); // Ambil semua elemen dengan kelas slot-game-item

        slotGameList.forEach(function(gameItem) {
            var gameName = gameItem.querySelector('.slot-game-name').textContent.toLowerCase(); // Ambil teks nama game dan konversi ke huruf kecil
            if (gameName.includes(searchTerm)) { // Periksa apakah nama game mengandung kata kunci pencarian
                gameItem.style.display = 'block'; // Tampilkan game jika cocok
            } else {
                gameItem.style.display = 'none'; // Sembunyikan game jika tidak cocok
            }
        });
    }
</script>

</main>