<footer class="footer">
    <div class="footer__provider">
      <div class="container">
        <div class="provider-header">PROVIDER</div>
        <div class="provider-holder">
          <div class="provider-content">
            <div class="provider-title">
              <img title="Slot" alt="Slot" src="https://images.linkcdn.cloud/global/icon-footer/Slot.png" width="20" height="20">
              <span>SLOT</span>
            </div>
            <div class="provider-logo">
              <img alt="Pragmatic Play" title="Pragmatic Play" src="https://images.linkcdn.cloud/global/logo-footer/slot/pra_footer.png" width="100" height="50">
              <img alt="Spade Gaming" title="Spade Gaming" src="https://images.linkcdn.cloud/global/logo-footer/slot/spd_footer.png" width="100" height="50">
              <img alt="PG Soft" title="PG Soft" src="https://images.linkcdn.cloud/global/logo-footer/slot/pgs_footer.png" width="100" height="50">
              <img alt="AIS GAMING" title="AIS GAMING" src="https://images.linkcdn.cloud/global/logo-footer/slot/aisg_footer.webp" width="100" height="50">
              <img alt="Fa Chai" title="Fa Chai" src="https://images.linkcdn.cloud/global/logo-footer/slot/fac_footer.webp" width="100" height="50">
              <img alt="RED TIGER" title="RED TIGER" src=" https://images.linkcdn.cloud/global/logo-footer/slot/rtr_footer.webp " width="100" height="50">
              <img alt="FASTSPIN" title="FASTSPIN" src="https://images.linkcdn.cloud/global/logo-footer/slot/fastspin_footer.png" width="100" height="50">
              <img alt="JILI" title="JILI" src="https://images.linkcdn.cloud/global/logo-footer/slot/jli_footer.webp" width="100" height="50">
              <img alt="HC Game" title="HC Game" src="https://images.linkcdn.cloud/global/logo-footer/slot/hcg_footer.png" width="100" height="50">
              <img alt="Advantplay" title="Advantplay" src="https://images.linkcdn.cloud/global/logo-footer/slot/adv_footer.png" width="100" height="50">
              <img alt="NoLimit City" title="NoLimit City" src="https://images.linkcdn.cloud/global/logo-footer/slot/nlc_footer.png" width="100" height="50">
              <img alt="JDB" title="JDB" src="https://images.linkcdn.cloud/global/logo-footer/slot/jdb_footer.webp" width="100" height="50">
              <img alt="Playstar" title="Playstar" src="https://images.linkcdn.cloud/global/logo-footer/slot/pls_footer.png" width="100" height="50">
              <img alt="VIVA" title="VIVA" src="https://images.linkcdn.cloud/global/logo-footer/slot/viva_footer.webp" width="100" height="50">
              <img alt="Joker Gaming" title="Joker Gaming" src="https://images.linkcdn.cloud/global/logo-footer/slot/jok_footer.png" width="100" height="50">
              <img alt="Habanero" title="Habanero" src="https://images.linkcdn.cloud/global/logo-footer/slot/hbn_footer.png" width="100" height="50">
              <img alt="Afb Gaming" title="Afb Gaming" src="https://images.linkcdn.cloud/global/logo-footer/slot/afg_footer.png" width="100" height="50">
              <img alt="CQ9 Gaming" title="CQ9 Gaming" src="https://images.linkcdn.cloud/global/logo-footer/slot/cq9_footer.png" width="100" height="50">
              <img alt="Virtual Tech" title="Virtual Tech" src="https://images.linkcdn.cloud/global/logo-footer/slot/vrt_footer.png" width="100" height="50">
              <img alt="Ameba" title="Ameba" src="https://images.linkcdn.cloud/global/logo-footer/slot/amb_footer.png" width="100" height="50">
              <img alt="Top Trend Gaming" title="Top Trend Gaming" src="https://images.linkcdn.cloud/global/logo-footer/slot/ttg_footer.png" width="100" height="50">
              <img alt="Microgaming" title="Microgaming" src="https://images.linkcdn.cloud/global/logo-footer/slot/micro_logo.png" width="100" height="50">
              <img alt="Playtech Slot" title="Playtech Slot" src="https://images.linkcdn.cloud/global/logo-footer/slot/pla_footer.png" width="100" height="50">
              <img alt="Play N Go" title="Play N Go" src="https://images.linkcdn.cloud/global/logo-footer/slot/png_footer.png" width="100" height="50">
              <img alt="Hydako" title="Hydako" src="https://images.linkcdn.cloud/global/logo-footer/slot/hyd_footer.png" width="100" height="50">
              <img alt="N2Live Slot" title="N2Live Slot" src="https://images.linkcdn.cloud/global/logo-footer/casino/nli_footer.png" width="100" height="50">
            </div>
          </div>
          <div class="provider-content">
            <div class="provider-title">
              <img title="Casino" alt="Casino" src="https://images.linkcdn.cloud/global/icon-footer/Casino.png" width="20" height="20">
              <span>CASINO</span>
            </div>
            <div class="provider-logo">
              <img alt="AFB CASINO" title="AFB CASINO" src="https://images.linkcdn.cloud/global/logo-footer/casino/afc_footer.webp" width="100" height="50">
              <img alt="Pragmatic Play LC" title="Pragmatic Play LC" src="https://images.linkcdn.cloud/global/logo-footer/casino/plc_footer.png" width="100" height="50">
              <img alt="GD88" title="GD88" src="https://images.linkcdn.cloud/global/logo-footer/casino/gd8_footer.png" width="100" height="50">
              <img alt="WM Casino" title="WM Casino" src="https://images.linkcdn.cloud/global/logo-footer/casino/wmc_footer.png" width="100" height="50">
              <img alt="OG Casino" title="OG Casino" src="https://images.linkcdn.cloud/global/logo-footer/casino/ogs_footer.png" width="100" height="50">
              <img alt="Evolution" title="Evolution" src="https://images.linkcdn.cloud/global/logo-footer/casino/evolution_footer.webp" width="100" height="50">
              <img alt="ALLBET" title="ALLBET" src="https://images.linkcdn.cloud/global/logo-footer/casino/alb_footer.png" width="100" height="50">
              <img alt="Dream Gaming" title="Dream Gaming" src="https://images.linkcdn.cloud/global/logo-footer/casino/drg_footer.png" width="100" height="50">
              <img alt="Asia Gaming" title="Asia Gaming" src="https://images.linkcdn.cloud/global/logo-footer/casino/agc_footer.png" width="100" height="50">
              <img alt="Sexy Gaming" title="Sexy Gaming" src="https://images.linkcdn.cloud/global/logo-footer/casino/seg_footer.png" width="100" height="50">
              <img alt="WE CASINO" title="WE CASINO" src="https://images.linkcdn.cloud/global/logo-footer/casino/wec_footer.png" width="100" height="50">
              <img alt="LG88" title="LG88" src="https://images.linkcdn.cloud/global/logo-footer/casino/lg8_footer.png" width="100" height="50">
              <img alt="N2Live" title="N2Live" src="https://images.linkcdn.cloud/global/logo-footer/casino/nli_footer.png" width="100" height="50">
            </div>
          </div>
          <div class="provider-content">
            <div class="row">
              <div class="col-lg-6">
                <div class="provider-title">
                  <img title="Sportsbook" alt="Sportsbook" src="https://images.linkcdn.cloud/global/icon-footer/Sport.png" width="20" height="20">
                  <span>SPORTSBOOK</span>
                </div>
                <div class="provider-logo">
                  <img alt="AFB88" title="AFB88" src="https://images.linkcdn.cloud/global/logo-footer/sports/afb_footer.png" width="100" height="50">
                  <img alt="IA E-SPORT" title="IA E-SPORT" src="https://images.linkcdn.cloud/global/logo-footer/sports/iae_footer.png" width="100" height="50">
                  <img alt="SBO SPORT" title="SBO SPORT" src="https://images.linkcdn.cloud/global/logo-footer/sports/sbo_footer.png" width="100" height="50">
                  <img alt="CMD368" title="CMD368" src="https://images.linkcdn.cloud/global/logo-footer/sports/cmd_footer.png" width="100" height="50">
                  <img alt="M88 SPORTS" title="M88 SPORTS" src="https://images.linkcdn.cloud/global/logo-footer/sports/m88_footer.webp" width="100" height="50">
                </div>
              </div>
              <div class="col-lg-6">
                <div class="provider-title">
                  <img title="Arcade" alt="Arcade" src="https://images.linkcdn.cloud/global/icon-footer/Arcade.png" width="20" height="20">
                  <span>ARCADE</span>
                </div>
                <div class="provider-logo">
                  <img alt="Spaceman" title="Spaceman" src="https://images.linkcdn.cloud/global/logo-footer/casino/spaceman_footer.webp" width="100" height="50">
                  <img alt="Joker Gaming" title="Joker Gaming" src="https://images.linkcdn.cloud/global/logo-footer/slot/jok_footer.png" width="100" height="50">
                  <img alt="Fa Chai" title="Fa Chai" src="https://images.linkcdn.cloud/global/logo-footer/slot/fac_footer.webp" width="100" height="50">
                  <img alt="Fastspin" title="Fastspin" src="https://images.linkcdn.cloud/global/logo-footer/slot/fastspin_footer.png" width="100" height="50">
                  <img alt="JDB" title="JDB" src="https://images.linkcdn.cloud/global/logo-footer/slot/jdb_footer.webp" width="100" height="50">
                  <img alt="Spade Gaming" title="Spade Gaming" src="https://images.linkcdn.cloud/global/logo-footer/slot/spd_footer.png" width="100" height="50">
                  <img alt="SPRIBE" title="SPRIBE" src="https://images.linkcdn.cloud/global/logo-footer/slot/spr_footer.webp" width="100" height="50">
                  <img alt="JILI" title="JILI" src=" https://images.linkcdn.cloud/global/logo-footer/slot/jli_footer.webp " width="100" height="50">
                </div>
              </div>
            </div>
          </div>
          <div class="provider-content">
            <div class="row">
              <div class="col-lg-3">
                <div class="provider-title">
                  <img title="Live Game" alt="Live Game" src="https://images.linkcdn.cloud/global/icon-footer/Game Lain.png" width="20" height="20">
                  <span>LIVE GAME</span>
                </div>
                <div class="provider-logo">
                  <img alt="LIVE GAME" title="LIVE GAME" src="https://images.linkcdn.cloud/global/logo-footer/others/lvg_footer.png" width="100" height="50">
                  <img alt="WS168" title="WS168" src="https://images.linkcdn.cloud/global/logo-footer/others/ws1_footer.webp" width="100" height="50">
                  <img alt="MIKI Gaming" title="MIKI Gaming" src="https://images.linkcdn.cloud/global/logo-footer/others/mki_footer.png" width="100" height="50">
                  <img alt="SV388 Cockfight" title="SV388 Cockfight" src="https://images.linkcdn.cloud/global/logo-footer/others/sv3_footer.png" width="100" height="50">
                </div>
              </div>
              <div class="col-lg-3">
                <div class="provider-title">
                  <img title="Lottery" alt="Lottery" src="https://images.linkcdn.cloud/global/icon-footer/Lottery.png" width="20" height="20">
                  <span>LOTTERY</span>
                </div>
                <div class="provider-logo">
                  <img alt="4D" title="4D" src="https://images.linkcdn.cloud/global/logo-footer/lottery/togel_footer.png" width="100" height="50">
                </div>
              </div>
              <div class="col-lg-3">
                <div class="provider-title">
                  <img title="Poker" alt="Poker" src="https://images.linkcdn.cloud/global/icon-footer/Poker.png" width="20" height="20">
                  <span>POKER</span>
                </div>
                <div class="provider-logo">
                  <img alt="We1Poker" title="We1Poker" src="https://images.linkcdn.cloud/global/logo-footer/poker/we1_footer.png" width="100" height="50">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Tambahkan tombol ke dalam struktur HTML -->
  <button id="scrollToTopBtn" onclick="scrollToTop()" title="Kembali ke Atas">TOP</button>

    <div class="footer__trademark">Copyright &copy; 2023
      <?php echo $judul ?> is an international registered trademark. All rights reserved.</div>
      
  </footer>
  <script>
      // JavaScript untuk mendeteksi posisi scroll dan mengatur visibilitas tombol
window.onscroll = function() {scrollFunction()};
function scrollFunction() {
    var scrollToTopBtn = document.getElementById("scrollToTopBtn");
    // Tampilkan tombol jika posisi scroll sudah mencapai bagian paling bawah halaman
    if ((window.innerHeight + window.scrollY) >= document.body.offsetHeight) {
        scrollToTopBtn.style.display = "block";
    } else {
        scrollToTopBtn.style.display = "none";
    }
}
// Fungsi untuk scroll ke atas ketika tombol diklik
function scrollToTop() {
    document.body.scrollTop = 0; // Untuk Safari
    document.documentElement.scrollTop = 0; // Untuk Chrome, Firefox, IE, dan Opera
}
  </script>